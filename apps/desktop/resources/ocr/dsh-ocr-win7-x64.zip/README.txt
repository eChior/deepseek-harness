dsh-ocr — Windows 7 (x64) 版
============================

运行要求
--------
1. Windows 7 SP1 64 位（或更高版本的 Windows）
2. .NET Framework 4.8 运行时
   检查方法（命令提示符）：
     reg query "HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" /v Release
   Release 值 >= 528040 即已安装 4.8；>= 533320 为 4.8.1
   未安装时请从微软官网下载 .NET Framework 4.8 离线安装包（Win7 需先装 SP1）

命令行
------
  dsh-ocr.exe <图片路径>        读一个文件（手工调试用）
  ... | dsh-ocr.exe             从 stdin 读 base64 图片（Host 正常调用方式）
  dsh-ocr.exe --json <图片>     输出机器可读报告（含每行四边形坐标）
  dsh-ocr.exe --chars <图片>    同 --json，并附每个字的四边形坐标
  dsh-ocr.exe --serve           常驻模式：stdin 每行一张 base64 图片，
                                stdout 每行一份 JSON 报告，模型只加载一次
  dsh-ocr.exe --version         打印 "dsh-ocr 2"
  dsh-ocr.exe --backend=cpu     CPU 后端（本版本唯一可用后端）

  不带开关时为纯文本输出，每行一条识别结果（UTF-8），与旧版完全兼容；
  也认环境变量 DSH_OCR_JSON=1，等价于 --json。

JSON 报告结构
-------------
  {"version":1,"backend":"cpu","elapsedMs":595,
   "image":{"width":900,"height":300},
   "text":"整页文本，行间用 \n",
   "lines":[{"text":"一行文本",
             "box":{"x1":..,"y1":..,"x2":..,"y2":..,"x3":..,"y3":..,"x4":..,"y4":..},
             "detectionScore":0.93,
             "recognitionScore":38.67,
             "classificationScore":1.0,
             "classificationLabel":0,
             "rotationDegrees":0,
             "characters":[{"text":"字","score":..,"box":{...}}]}]}

  box 是行/字的四个角点，单位为输入图片的像素，顺序为左上、右上、右下、左下。

退出码
------
  0   成功（文本可能为空）
  3   stdin 没有数据
  4   未知命令行选项

实现说明
--------
- 纯 CPU 推理（Sdcb.SimdPaddleOCR 2.0.0 的 netstandard2.0 目标），
  GPU（Vulkan/Metal）仅 .NET 10 版本支持，此版本不包含；传 --backend=vulkan
  会在 stderr 提示后按 CPU 运行。
- 图片解码用 Windows 自带的 GDI+（System.Drawing），不依赖 SkiaSharp，
  因此不需要额外 native DLL。
- 模型（ChineseV6Tiny）内嵌在 DLL 中，不联网。

整个目录必须保持完整（exe 与同目录 dll 一起分发），解压后约 8.6 MB。
