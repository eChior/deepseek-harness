dsh-ocr — Windows 7 (x64) 版
============================

运行要求
--------
1. Windows 7 SP1 64 位（或更高版本的 Windows）
2. .NET Framework 4.8 运行时
   检查方法（命令提示符）：
     reg query "HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" /v Release
   Release 值 >= 528040 即已安装 4.8；>= 533320 为 4.8.1
   未安装时请从微软官网下载 .NET Framework 4.8 离线安装包（Win7 需先装 SP1）

使用方式
--------
与本产品其它平台的 dsh-ocr 完全一致，二选一：

  a) 传图片文件路径：
       dsh-ocr.exe C:\\path\\to\\image.png

  b) 从标准输入传 base64 编码的图片数据的（Host 正常调用的方式）：
       ... | dsh-ocr.exe

成功时标准输出为识别文本，每行一条，UTF-8 编码；
标准输入为空时返回 3，并在 stderr 提示 "no image data on stdin"。

实现说明
--------
- 纯 CPU 推理（Sdcb.SimdPaddleOCR 2.0.0 的 netstandard2.0 目标），
  GPU（Vulkan/Metal）仅 .NET 10 版本支持，此版本不包含。
- 图片解码用 Windows 自带的 GDI+（System.Drawing），不依赖 SkiaSharp，
  因此不需要额外的 native DLL。
- 引擎本身是纯托管代码，模型（ChineseV6Tiny）内嵌在 DLL 中，
  不联网、不写临时文件。

整个目录必须保持完整（exe 与同目录 dll 一起分发），约 7.8 MB。
